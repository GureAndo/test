<p>
    <strong>Voici mon contenu</strong><br>
    <em>Rappel: Je suis du code exclusivement en HTML</em>
</p>